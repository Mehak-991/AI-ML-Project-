--
-- PostgreSQL database dump
--

\restrict 35YjahiemzObe6hmcrDdMeU3mIucYXQFPZ4htrivt6N6OigbIlA3VSZ92G4Damx

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasets (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    stored_filename character varying(255) NOT NULL,
    file_format character varying(16) NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character varying(64) NOT NULL,
    n_rows integer NOT NULL,
    n_columns integer NOT NULL,
    columns jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployments (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    status character varying(32) DEFAULT 'Ready'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    environment character varying(64) DEFAULT 'production'::character varying NOT NULL,
    endpoint_url character varying(255) NOT NULL,
    configuration jsonb NOT NULL,
    deployed_at character varying(64),
    undeployed_at character varying(64),
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: drift_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drift_alerts (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    drift_report_id uuid NOT NULL,
    alert_type character varying(32) NOT NULL,
    severity character varying(16) NOT NULL,
    feature_name character varying(255),
    metric_name character varying(64),
    metric_value double precision,
    threshold double precision,
    message text NOT NULL,
    resolved boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: drift_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drift_reports (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    report_type character varying(32) NOT NULL,
    overall_status character varying(32) DEFAULT 'normal'::character varying NOT NULL,
    results json DEFAULT '{}'::json NOT NULL,
    sample_size integer DEFAULT 0 NOT NULL,
    summary text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: experiment_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.experiment_runs (
    id uuid NOT NULL,
    experiment_id uuid NOT NULL,
    run_number integer DEFAULT 1 NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    best_hyperparameters jsonb,
    validation_metrics jsonb,
    test_metrics jsonb,
    cv_results jsonb,
    registered_model_id uuid,
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    execution_duration_seconds double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: experiments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.experiments (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    dataset_id uuid NOT NULL,
    target_column character varying(255) NOT NULL,
    problem_type character varying(50) NOT NULL,
    algorithm character varying(50) NOT NULL,
    selected_features jsonb,
    hyperparameter_config jsonb NOT NULL,
    search_strategy character varying(50) DEFAULT 'none'::character varying NOT NULL,
    cv_folds integer DEFAULT 5 NOT NULL,
    scoring_metric character varying(50),
    test_size double precision DEFAULT '0.2'::double precision NOT NULL,
    validation_size double precision DEFAULT '0.1'::double precision NOT NULL,
    random_state integer DEFAULT 42 NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    dataset_fingerprint character varying(128),
    created_by_id uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    execution_duration_seconds double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id uuid NOT NULL,
    job_type character varying(64) NOT NULL,
    status character varying(32) DEFAULT 'queued'::character varying NOT NULL,
    created_by_id uuid,
    model_id uuid,
    experiment_id uuid,
    input_config jsonb NOT NULL,
    progress_percentage integer DEFAULT 0 NOT NULL,
    current_stage character varying(128),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    execution_duration_seconds double precision,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    error_category character varying(128),
    error_message text,
    result jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    worker_id character varying(128),
    heartbeat_at timestamp with time zone
);


--
-- Name: ml_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_models (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    dataset_id uuid NOT NULL,
    problem_type character varying(32) NOT NULL,
    algorithm character varying(64) NOT NULL,
    target_column character varying(255) NOT NULL,
    feature_schema jsonb NOT NULL,
    metrics jsonb NOT NULL,
    training_metadata jsonb NOT NULL,
    artifact_filename character varying(255) NOT NULL,
    artifact_sha256 character varying(64) NOT NULL,
    sklearn_version character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    owner_id uuid
);


--
-- Name: prediction_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prediction_logs (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    deployment_id uuid,
    record_count integer DEFAULT 1 NOT NULL,
    duration_ms double precision DEFAULT '0'::double precision NOT NULL,
    status character varying(32) DEFAULT 'success'::character varying NOT NULL,
    problem_type character varying(32) NOT NULL,
    error_category character varying(64),
    error_message text,
    prediction_summary jsonb,
    ground_truth jsonb,
    is_evaluated boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    requested_by_id uuid
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at character varying(64) NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255) DEFAULT ''::character varying NOT NULL,
    role character varying(32) DEFAULT 'viewer'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0011
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasets (id, name, original_filename, stored_filename, file_format, size_bytes, sha256, n_rows, n_columns, columns, created_at, updated_at) FROM stdin;
3081c007-0a5d-42c0-872b-bc1b0ce9fd92	string	sample_students.csv	e43c1b68d3f24adb8690ba959eb866cc.csv	csv	178	79a1e29bb3fd10e4518189952f786ba7e470f07bae2c6426d1800d59d4720e3f	10	5	[{"kind": "numeric", "name": "age", "dtype": "int64"}, {"kind": "numeric", "name": "experience_years", "dtype": "int64"}, {"kind": "numeric", "name": "study_hours", "dtype": "int64"}, {"kind": "numeric", "name": "attendance", "dtype": "int64"}, {"kind": "numeric", "name": "placement", "dtype": "int64"}]	2026-10-30 14:08:27.397232+05:30	2026-10-30 14:08:27.397232+05:30
fd99c740-11e9-4111-b83c-933ab7495d9d	string	sample_students.csv	dddac687d5a7416287a5dcea80839648.csv	csv	178	79a1e29bb3fd10e4518189952f786ba7e470f07bae2c6426d1800d59d4720e3f	10	5	[{"kind": "numeric", "name": "age", "dtype": "int64"}, {"kind": "numeric", "name": "experience_years", "dtype": "int64"}, {"kind": "numeric", "name": "study_hours", "dtype": "int64"}, {"kind": "numeric", "name": "attendance", "dtype": "int64"}, {"kind": "numeric", "name": "placement", "dtype": "int64"}]	2026-10-30 14:21:16.563996+05:30	2026-10-30 14:21:16.563996+05:30
bf91a9e8-8c00-459a-9412-32b38fcdd6ab	string	sample_students_final.csv	f0efac6fd98b41658a06f8f63c908b81.csv	csv	537	8d2054daea8d14db0391a4424c5881270093ee6c51b230d58c0aedaea429e345	40	5	[{"kind": "numeric", "name": "age", "dtype": "int64"}, {"kind": "numeric", "name": "experience_years", "dtype": "int64"}, {"kind": "numeric", "name": "study_hours", "dtype": "int64"}, {"kind": "numeric", "name": "attendance", "dtype": "int64"}, {"kind": "numeric", "name": "placement", "dtype": "int64"}]	2026-10-30 14:41:11.490087+05:30	2026-10-30 14:41:11.490087+05:30
5d082720-c2ee-485c-9748-3208c4e7a280	Sample students final	sample_students_final.csv	32c9700788b546b2bef15abe2adbc0ae.csv	csv	537	8d2054daea8d14db0391a4424c5881270093ee6c51b230d58c0aedaea429e345	40	5	[{"kind": "numeric", "name": "age", "dtype": "int64"}, {"kind": "numeric", "name": "experience_years", "dtype": "int64"}, {"kind": "numeric", "name": "study_hours", "dtype": "int64"}, {"kind": "numeric", "name": "attendance", "dtype": "int64"}, {"kind": "numeric", "name": "placement", "dtype": "int64"}]	2026-10-30 15:58:27.115996+05:30	2026-10-30 15:58:27.115996+05:30
\.


--
-- Data for Name: deployments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deployments (id, model_id, status, version, environment, endpoint_url, configuration, deployed_at, undeployed_at, error_message, created_at, updated_at) FROM stdin;
a95d8f8a-ff0e-4648-9d76-7265ba4b0a34	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	Deployed	1	production	/api/v1/models/23359afd-b2a4-46c2-afa6-e18d6f77dc9e/predict	{"replicas": 1}	2026-10-30T11:43:51.738181+00:00	\N	\N	2026-10-30 17:13:51.708249+05:30	2026-10-30 17:13:51.708249+05:30
\.


--
-- Data for Name: drift_alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drift_alerts (id, model_id, drift_report_id, alert_type, severity, feature_name, metric_name, metric_value, threshold, message, resolved, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drift_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drift_reports (id, model_id, report_type, overall_status, results, sample_size, summary, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: experiment_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.experiment_runs (id, experiment_id, run_number, status, best_hyperparameters, validation_metrics, test_metrics, cv_results, registered_model_id, error_message, started_at, completed_at, execution_duration_seconds, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: experiments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.experiments (id, name, description, dataset_id, target_column, problem_type, algorithm, selected_features, hyperparameter_config, search_strategy, cv_folds, scoring_metric, test_size, validation_size, random_state, status, dataset_fingerprint, created_by_id, started_at, completed_at, execution_duration_seconds, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, job_type, status, created_by_id, model_id, experiment_id, input_config, progress_percentage, current_stage, started_at, completed_at, execution_duration_seconds, retry_count, max_retries, error_category, error_message, result, created_at, updated_at, worker_id, heartbeat_at) FROM stdin;
\.


--
-- Data for Name: ml_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_models (id, name, dataset_id, problem_type, algorithm, target_column, feature_schema, metrics, training_metadata, artifact_filename, artifact_sha256, sklearn_version, created_at, updated_at, version, owner_id) FROM stdin;
23359afd-b2a4-46c2-afa6-e18d6f77dc9e	Student Placement Classifier	bf91a9e8-8c00-459a-9412-32b38fcdd6ab	classification	linear	placement	[{"kind": "numeric", "name": "age"}, {"kind": "numeric", "name": "experience_years"}, {"kind": "numeric", "name": "study_hours"}, {"kind": "numeric", "name": "attendance"}]	{"test": {"roc_auc": 1.0, "accuracy": 1.0, "f1_macro": 1.0, "log_loss": 0.208071, "n_samples": 8, "recall_macro": 1.0, "precision_macro": 1.0, "confusion_matrix": {"labels": [0, 1], "matrix": [[4, 0], [0, 4]]}, "balanced_accuracy": 1.0}, "train": {"roc_auc": 1.0, "accuracy": 1.0, "f1_macro": 1.0, "log_loss": 0.113015, "n_samples": 24, "recall_macro": 1.0, "precision_macro": 1.0, "confusion_matrix": {"labels": [0, 1], "matrix": [[11, 0], [0, 13]]}, "balanced_accuracy": 1.0}, "validation": {"roc_auc": 1.0, "accuracy": 0.875, "f1_macro": 0.873016, "log_loss": 0.236783, "n_samples": 8, "recall_macro": 0.875, "precision_macro": 0.9, "confusion_matrix": {"labels": [0, 1], "matrix": [[4, 0], [1, 3]]}, "balanced_accuracy": 0.875}, "baseline_test": {"roc_auc": 0.5, "accuracy": 0.5, "f1_macro": 0.333333, "log_loss": 18.021827, "n_samples": 8, "recall_macro": 0.5, "precision_macro": 0.25, "confusion_matrix": {"labels": [0, 1], "matrix": [[0, 4], [0, 4]]}, "balanced_accuracy": 0.5}}	{"rows": {"raw": 40, "test": 8, "used": 40, "train": 24, "validation": 8, "dropped_duplicates": 0, "dropped_missing_target": 0}, "config": {"test_size": 0.2, "random_state": 42, "drop_duplicates": true, "validation_size": 0.2, "problem_type_inferred": false}, "versions": {"numpy": "2.5.4", "pandas": "3.1.0", "scikit-learn": "1.9.1"}, "estimator": "LogisticRegression", "stratified": true, "trained_at": "2026-10-30T09:13:19.544998+00:00", "class_labels": [0, 1], "baseline_model": "DummyClassifier", "dataset_sha256": "8d2054daea8d14db0391a4424c5881270093ee6c51b230d58c0aedaea429e345", "dropped_columns": [], "training_seconds": 0.17, "validation_warnings": []}	2a0b0f6d709749558a4dd98c730871b0.joblib	3d17389cb92f3e3f10b247bbf56177e9145dbf8826b7ea0a0126a62d7b88026e	1.9.1	2026-10-30 14:43:19.361104+05:30	2026-10-30 14:43:19.361104+05:30	1	\N
\.


--
-- Data for Name: prediction_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prediction_logs (id, model_id, deployment_id, record_count, duration_ms, status, problem_type, error_category, error_message, prediction_summary, ground_truth, is_evaluated, created_at, updated_at, requested_by_id) FROM stdin;
44c2d3ca-e566-4221-be34-a8ec26162110	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	a95d8f8a-ff0e-4648-9d76-7265ba4b0a34	1	112.7	success	classification	\N	\N	{"count": 1, "predictions": [1]}	[1]	t	2026-10-30 17:14:09.497212+05:30	2026-10-30 17:14:55.388459+05:30	\N
eb96d3c5-aa48-41c8-b6a0-a2259e86ad96	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	a95d8f8a-ff0e-4648-9d76-7265ba4b0a34	1	388.14	success	classification	\N	\N	{"count": 1, "predictions": [1]}	\N	f	2026-10-31 03:18:44.798343+05:30	2026-10-31 03:18:44.798343+05:30	\N
ce3f08fe-133c-4e6f-8380-1a7cb780b3a1	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	a95d8f8a-ff0e-4648-9d76-7265ba4b0a34	1	43.09	success	classification	\N	\N	{"count": 1, "predictions": [1]}	\N	f	2026-10-31 03:18:51.136453+05:30	2026-10-31 03:18:51.136453+05:30	\N
a59c0c11-d86a-407b-99ae-3c4948b924f2	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	a95d8f8a-ff0e-4648-9d76-7265ba4b0a34	1	111.17	success	classification	\N	\N	{"count": 1, "predictions": [1]}	\N	f	2026-10-31 03:19:00.80651+05:30	2026-10-31 03:19:00.80651+05:30	\N
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, revoked, created_at, updated_at) FROM stdin;
5930b963-0c18-410f-9b77-2ed50ed4f527	1d50d665-020d-4123-a87a-665b1f764f4e	b6ae1a866fb03a5c44b648bc41fbd977df008dfaf1aa57445483cfcf702587d3	2026-11-06T20:26:27.781016+00:00	t	2026-10-31 01:56:27.762167+05:30	2026-10-31 01:56:36.639127+05:30
61363940-6cc0-4ce4-975a-9e77e0e2fe37	971950d6-1c6a-4cb5-aba9-6cd0181b879a	0068dbaec02d0a073618e4b2bd77096683b45c9002d82d8427d62654cb55ab70	2026-11-10T11:04:16.880710+00:00	t	2026-11-03 16:34:16.862609+05:30	2026-11-03 16:34:17.293114+05:30
bb1f02aa-cb45-4896-be62-df777c818c80	971950d6-1c6a-4cb5-aba9-6cd0181b879a	0837bb398c49ada8dbd03e60f1997b8be25a9752f8773eb4bc48afeaa6704979	2026-11-10T11:04:17.308427+00:00	t	2026-11-03 16:34:17.293114+05:30	2026-11-03 16:34:17.375155+05:30
5fdb0ae5-93a7-4ef7-b9cb-b13467e62f09	971950d6-1c6a-4cb5-aba9-6cd0181b879a	f6f9abce7f15469dc5e64559c930a8866b02ab9225adfe4a954c7fdad706c889	2026-11-10T11:04:17.462288+00:00	t	2026-11-03 16:34:17.442851+05:30	2026-11-03 16:34:17.475296+05:30
cfd4dc24-34c0-4f09-9fb5-d38302aa2d30	971950d6-1c6a-4cb5-aba9-6cd0181b879a	8cacd01ec2de03c5c5db916c862b714848e59dc8ae3cec5613ea47d6d883440a	2026-11-10T11:04:17.539735+00:00	f	2026-11-03 16:34:17.517882+05:30	2026-11-03 16:34:17.517882+05:30
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, hashed_password, full_name, role, is_active, created_at, updated_at) FROM stdin;
1d50d665-020d-4123-a87a-665b1f764f4e	mehak66@gmail.com	$pbkdf2-sha256$29000$WWtNiRHiXOs9Z0wJQehdqw$jL98dnyRmoXIgOHcegTgKUF.Ll1q7RtLtHv5sqdKyeA	mehak	admin	t	2026-10-31 01:56:27.704117+05:30	2026-10-31 01:56:27.704117+05:30
971950d6-1c6a-4cb5-aba9-6cd0181b879a	auth-test-3fe682d8@example.com	$pbkdf2-sha256$29000$iTGGcO4dg3COUaqVkjLmnA$sOUGlgEIW5KkdYvKzumQhU6XLR6nWnCNxIikT/QbdeA	Auth Test	viewer	t	2026-11-03 16:34:16.694614+05:30	2026-11-03 16:34:16.694614+05:30
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: datasets pk_datasets; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT pk_datasets PRIMARY KEY (id);


--
-- Name: deployments pk_deployments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT pk_deployments PRIMARY KEY (id);


--
-- Name: drift_alerts pk_drift_alerts; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_alerts
    ADD CONSTRAINT pk_drift_alerts PRIMARY KEY (id);


--
-- Name: drift_reports pk_drift_reports; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_reports
    ADD CONSTRAINT pk_drift_reports PRIMARY KEY (id);


--
-- Name: experiment_runs pk_experiment_runs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT pk_experiment_runs PRIMARY KEY (id);


--
-- Name: experiments pk_experiments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT pk_experiments PRIMARY KEY (id);


--
-- Name: jobs pk_jobs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT pk_jobs PRIMARY KEY (id);


--
-- Name: ml_models pk_ml_models; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT pk_ml_models PRIMARY KEY (id);


--
-- Name: prediction_logs pk_prediction_logs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prediction_logs
    ADD CONSTRAINT pk_prediction_logs PRIMARY KEY (id);


--
-- Name: refresh_tokens pk_refresh_tokens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT pk_refresh_tokens PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: datasets uq_datasets_stored_filename; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT uq_datasets_stored_filename UNIQUE (stored_filename);


--
-- Name: ml_models uq_ml_models_artifact_filename; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT uq_ml_models_artifact_filename UNIQUE (artifact_filename);


--
-- Name: ml_models uq_ml_models_name_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT uq_ml_models_name_version UNIQUE (name, version);


--
-- Name: ix_datasets_sha256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_datasets_sha256 ON public.datasets USING btree (sha256);


--
-- Name: ix_deployments_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deployments_model_id ON public.deployments USING btree (model_id);


--
-- Name: ix_deployments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deployments_status ON public.deployments USING btree (status);


--
-- Name: ix_drift_alerts_drift_report_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_alerts_drift_report_id ON public.drift_alerts USING btree (drift_report_id);


--
-- Name: ix_drift_alerts_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_alerts_model_id ON public.drift_alerts USING btree (model_id);


--
-- Name: ix_drift_alerts_resolved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_alerts_resolved ON public.drift_alerts USING btree (resolved);


--
-- Name: ix_drift_alerts_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_alerts_severity ON public.drift_alerts USING btree (severity);


--
-- Name: ix_drift_reports_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_reports_model_id ON public.drift_reports USING btree (model_id);


--
-- Name: ix_drift_reports_overall_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_reports_overall_status ON public.drift_reports USING btree (overall_status);


--
-- Name: ix_drift_reports_report_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_reports_report_type ON public.drift_reports USING btree (report_type);


--
-- Name: ix_experiment_runs_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiment_runs_experiment_id ON public.experiment_runs USING btree (experiment_id);


--
-- Name: ix_experiment_runs_registered_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiment_runs_registered_model_id ON public.experiment_runs USING btree (registered_model_id);


--
-- Name: ix_experiment_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiment_runs_status ON public.experiment_runs USING btree (status);


--
-- Name: ix_experiments_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiments_created_by_id ON public.experiments USING btree (created_by_id);


--
-- Name: ix_experiments_dataset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiments_dataset_id ON public.experiments USING btree (dataset_id);


--
-- Name: ix_experiments_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiments_name ON public.experiments USING btree (name);


--
-- Name: ix_experiments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiments_status ON public.experiments USING btree (status);


--
-- Name: ix_jobs_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_created_by_id ON public.jobs USING btree (created_by_id);


--
-- Name: ix_jobs_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_experiment_id ON public.jobs USING btree (experiment_id);


--
-- Name: ix_jobs_job_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_job_type ON public.jobs USING btree (job_type);


--
-- Name: ix_jobs_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_model_id ON public.jobs USING btree (model_id);


--
-- Name: ix_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_status ON public.jobs USING btree (status);


--
-- Name: ix_jobs_status_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_status_created_at ON public.jobs USING btree (status, created_at) WHERE ((status)::text = ANY ((ARRAY['queued'::character varying, 'running'::character varying, 'retry_pending'::character varying])::text[]));


--
-- Name: ix_ml_models_dataset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ml_models_dataset_id ON public.ml_models USING btree (dataset_id);


--
-- Name: ix_ml_models_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ml_models_owner_id ON public.ml_models USING btree (owner_id);


--
-- Name: ix_prediction_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prediction_logs_created_at ON public.prediction_logs USING btree (created_at);


--
-- Name: ix_prediction_logs_deployment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prediction_logs_deployment_id ON public.prediction_logs USING btree (deployment_id);


--
-- Name: ix_prediction_logs_model_id_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prediction_logs_model_id_created_at ON public.prediction_logs USING btree (model_id, created_at);


--
-- Name: ix_prediction_logs_requested_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prediction_logs_requested_by_id ON public.prediction_logs USING btree (requested_by_id);


--
-- Name: ix_prediction_logs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prediction_logs_status ON public.prediction_logs USING btree (status);


--
-- Name: ix_refresh_tokens_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_refresh_tokens_token_hash ON public.refresh_tokens USING btree (token_hash);


--
-- Name: ix_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: deployments fk_deployments_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT fk_deployments_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE CASCADE;


--
-- Name: drift_alerts fk_drift_alerts_drift_report_id_drift_reports; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_alerts
    ADD CONSTRAINT fk_drift_alerts_drift_report_id_drift_reports FOREIGN KEY (drift_report_id) REFERENCES public.drift_reports(id) ON DELETE CASCADE;


--
-- Name: drift_alerts fk_drift_alerts_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_alerts
    ADD CONSTRAINT fk_drift_alerts_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE CASCADE;


--
-- Name: drift_reports fk_drift_reports_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_reports
    ADD CONSTRAINT fk_drift_reports_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE CASCADE;


--
-- Name: experiment_runs fk_experiment_runs_experiment_id_experiments; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT fk_experiment_runs_experiment_id_experiments FOREIGN KEY (experiment_id) REFERENCES public.experiments(id) ON DELETE CASCADE;


--
-- Name: experiment_runs fk_experiment_runs_registered_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT fk_experiment_runs_registered_model_id_ml_models FOREIGN KEY (registered_model_id) REFERENCES public.ml_models(id) ON DELETE SET NULL;


--
-- Name: experiments fk_experiments_created_by_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT fk_experiments_created_by_id_users FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: experiments fk_experiments_dataset_id_datasets; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT fk_experiments_dataset_id_datasets FOREIGN KEY (dataset_id) REFERENCES public.datasets(id) ON DELETE CASCADE;


--
-- Name: jobs fk_jobs_created_by_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_jobs_created_by_id_users FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: jobs fk_jobs_experiment_id_experiments; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_jobs_experiment_id_experiments FOREIGN KEY (experiment_id) REFERENCES public.experiments(id) ON DELETE SET NULL;


--
-- Name: jobs fk_jobs_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_jobs_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE SET NULL;


--
-- Name: ml_models fk_ml_models_dataset_id_datasets; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT fk_ml_models_dataset_id_datasets FOREIGN KEY (dataset_id) REFERENCES public.datasets(id) ON DELETE RESTRICT;


--
-- Name: ml_models fk_ml_models_owner_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT fk_ml_models_owner_id_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: prediction_logs fk_prediction_logs_deployment_id_deployments; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prediction_logs
    ADD CONSTRAINT fk_prediction_logs_deployment_id_deployments FOREIGN KEY (deployment_id) REFERENCES public.deployments(id) ON DELETE SET NULL;


--
-- Name: prediction_logs fk_prediction_logs_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prediction_logs
    ADD CONSTRAINT fk_prediction_logs_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE CASCADE;


--
-- Name: prediction_logs fk_prediction_logs_requested_by_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prediction_logs
    ADD CONSTRAINT fk_prediction_logs_requested_by_id_users FOREIGN KEY (requested_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: refresh_tokens fk_refresh_tokens_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT fk_refresh_tokens_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 35YjahiemzObe6hmcrDdMeU3mIucYXQFPZ4htrivt6N6OigbIlA3VSZ92G4Damx

