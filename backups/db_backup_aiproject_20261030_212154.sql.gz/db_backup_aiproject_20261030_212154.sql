--
-- PostgreSQL database dump
--

\restrict S3L7vPm1957P8hOT2auRxHMiBUc95GhhkPa7bbJ622YhFZLXelmffMWXJ63jr1B

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS fk_refresh_tokens_user_id_users;
ALTER TABLE IF EXISTS ONLY public.prediction_logs DROP CONSTRAINT IF EXISTS fk_prediction_logs_model_id_ml_models;
ALTER TABLE IF EXISTS ONLY public.prediction_logs DROP CONSTRAINT IF EXISTS fk_prediction_logs_deployment_id_deployments;
ALTER TABLE IF EXISTS ONLY public.ml_models DROP CONSTRAINT IF EXISTS fk_ml_models_dataset_id_datasets;
ALTER TABLE IF EXISTS ONLY public.jobs DROP CONSTRAINT IF EXISTS fk_jobs_model_id_ml_models;
ALTER TABLE IF EXISTS ONLY public.jobs DROP CONSTRAINT IF EXISTS fk_jobs_experiment_id_experiments;
ALTER TABLE IF EXISTS ONLY public.jobs DROP CONSTRAINT IF EXISTS fk_jobs_created_by_id_users;
ALTER TABLE IF EXISTS ONLY public.experiments DROP CONSTRAINT IF EXISTS fk_experiments_dataset_id_datasets;
ALTER TABLE IF EXISTS ONLY public.experiments DROP CONSTRAINT IF EXISTS fk_experiments_created_by_id_users;
ALTER TABLE IF EXISTS ONLY public.experiment_runs DROP CONSTRAINT IF EXISTS fk_experiment_runs_registered_model_id_ml_models;
ALTER TABLE IF EXISTS ONLY public.experiment_runs DROP CONSTRAINT IF EXISTS fk_experiment_runs_experiment_id_experiments;
ALTER TABLE IF EXISTS ONLY public.drift_reports DROP CONSTRAINT IF EXISTS fk_drift_reports_model_id_ml_models;
ALTER TABLE IF EXISTS ONLY public.drift_alerts DROP CONSTRAINT IF EXISTS fk_drift_alerts_model_id_ml_models;
ALTER TABLE IF EXISTS ONLY public.drift_alerts DROP CONSTRAINT IF EXISTS fk_drift_alerts_drift_report_id_drift_reports;
ALTER TABLE IF EXISTS ONLY public.deployments DROP CONSTRAINT IF EXISTS fk_deployments_model_id_ml_models;
DROP INDEX IF EXISTS public.ix_users_role;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_refresh_tokens_user_id;
DROP INDEX IF EXISTS public.ix_refresh_tokens_token_hash;
DROP INDEX IF EXISTS public.ix_prediction_logs_status;
DROP INDEX IF EXISTS public.ix_prediction_logs_model_id;
DROP INDEX IF EXISTS public.ix_prediction_logs_deployment_id;
DROP INDEX IF EXISTS public.ix_ml_models_dataset_id;
DROP INDEX IF EXISTS public.ix_jobs_status;
DROP INDEX IF EXISTS public.ix_jobs_model_id;
DROP INDEX IF EXISTS public.ix_jobs_job_type;
DROP INDEX IF EXISTS public.ix_jobs_experiment_id;
DROP INDEX IF EXISTS public.ix_jobs_created_by_id;
DROP INDEX IF EXISTS public.ix_experiments_status;
DROP INDEX IF EXISTS public.ix_experiments_name;
DROP INDEX IF EXISTS public.ix_experiments_dataset_id;
DROP INDEX IF EXISTS public.ix_experiments_created_by_id;
DROP INDEX IF EXISTS public.ix_experiment_runs_status;
DROP INDEX IF EXISTS public.ix_experiment_runs_registered_model_id;
DROP INDEX IF EXISTS public.ix_experiment_runs_experiment_id;
DROP INDEX IF EXISTS public.ix_drift_reports_report_type;
DROP INDEX IF EXISTS public.ix_drift_reports_overall_status;
DROP INDEX IF EXISTS public.ix_drift_reports_model_id;
DROP INDEX IF EXISTS public.ix_drift_alerts_severity;
DROP INDEX IF EXISTS public.ix_drift_alerts_resolved;
DROP INDEX IF EXISTS public.ix_drift_alerts_model_id;
DROP INDEX IF EXISTS public.ix_drift_alerts_drift_report_id;
DROP INDEX IF EXISTS public.ix_deployments_status;
DROP INDEX IF EXISTS public.ix_deployments_model_id;
DROP INDEX IF EXISTS public.ix_datasets_sha256;
ALTER TABLE IF EXISTS ONLY public.ml_models DROP CONSTRAINT IF EXISTS uq_ml_models_name_version;
ALTER TABLE IF EXISTS ONLY public.ml_models DROP CONSTRAINT IF EXISTS uq_ml_models_artifact_filename;
ALTER TABLE IF EXISTS ONLY public.datasets DROP CONSTRAINT IF EXISTS uq_datasets_stored_filename;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS pk_users;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS pk_refresh_tokens;
ALTER TABLE IF EXISTS ONLY public.prediction_logs DROP CONSTRAINT IF EXISTS pk_prediction_logs;
ALTER TABLE IF EXISTS ONLY public.ml_models DROP CONSTRAINT IF EXISTS pk_ml_models;
ALTER TABLE IF EXISTS ONLY public.jobs DROP CONSTRAINT IF EXISTS pk_jobs;
ALTER TABLE IF EXISTS ONLY public.experiments DROP CONSTRAINT IF EXISTS pk_experiments;
ALTER TABLE IF EXISTS ONLY public.experiment_runs DROP CONSTRAINT IF EXISTS pk_experiment_runs;
ALTER TABLE IF EXISTS ONLY public.drift_reports DROP CONSTRAINT IF EXISTS pk_drift_reports;
ALTER TABLE IF EXISTS ONLY public.drift_alerts DROP CONSTRAINT IF EXISTS pk_drift_alerts;
ALTER TABLE IF EXISTS ONLY public.deployments DROP CONSTRAINT IF EXISTS pk_deployments;
ALTER TABLE IF EXISTS ONLY public.datasets DROP CONSTRAINT IF EXISTS pk_datasets;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.refresh_tokens;
DROP TABLE IF EXISTS public.prediction_logs;
DROP TABLE IF EXISTS public.ml_models;
DROP TABLE IF EXISTS public.jobs;
DROP TABLE IF EXISTS public.experiments;
DROP TABLE IF EXISTS public.experiment_runs;
DROP TABLE IF EXISTS public.drift_reports;
DROP TABLE IF EXISTS public.drift_alerts;
DROP TABLE IF EXISTS public.deployments;
DROP TABLE IF EXISTS public.datasets;
DROP TABLE IF EXISTS public.alembic_version;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasets (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    stored_filename character varying(255) NOT NULL,
    file_format character varying(16) NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character varying(64) NOT NULL,
    n_rows integer NOT NULL,
    n_columns integer NOT NULL,
    columns jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployments (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    status character varying(32) DEFAULT 'Ready'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    environment character varying(64) DEFAULT 'production'::character varying NOT NULL,
    endpoint_url character varying(255) NOT NULL,
    configuration jsonb NOT NULL,
    deployed_at character varying(64),
    undeployed_at character varying(64),
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: drift_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drift_alerts (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    drift_report_id uuid NOT NULL,
    alert_type character varying(32) NOT NULL,
    severity character varying(16) NOT NULL,
    feature_name character varying(255),
    metric_name character varying(64),
    metric_value double precision,
    threshold double precision,
    message text NOT NULL,
    resolved boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: drift_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drift_reports (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    report_type character varying(32) NOT NULL,
    overall_status character varying(32) DEFAULT 'normal'::character varying NOT NULL,
    results json DEFAULT '{}'::json NOT NULL,
    sample_size integer DEFAULT 0 NOT NULL,
    summary text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: experiment_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.experiment_runs (
    id uuid NOT NULL,
    experiment_id uuid NOT NULL,
    run_number integer DEFAULT 1 NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    best_hyperparameters jsonb,
    validation_metrics jsonb,
    test_metrics jsonb,
    cv_results jsonb,
    registered_model_id uuid,
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    execution_duration_seconds double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: experiments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.experiments (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    dataset_id uuid NOT NULL,
    target_column character varying(255) NOT NULL,
    problem_type character varying(50) NOT NULL,
    algorithm character varying(50) NOT NULL,
    selected_features jsonb,
    hyperparameter_config jsonb NOT NULL,
    search_strategy character varying(50) DEFAULT 'none'::character varying NOT NULL,
    cv_folds integer DEFAULT 5 NOT NULL,
    scoring_metric character varying(50),
    test_size double precision DEFAULT '0.2'::double precision NOT NULL,
    validation_size double precision DEFAULT '0.1'::double precision NOT NULL,
    random_state integer DEFAULT 42 NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    dataset_fingerprint character varying(128),
    created_by_id uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    execution_duration_seconds double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id uuid NOT NULL,
    job_type character varying(64) NOT NULL,
    status character varying(32) DEFAULT 'queued'::character varying NOT NULL,
    created_by_id uuid,
    model_id uuid,
    experiment_id uuid,
    input_config jsonb NOT NULL,
    progress_percentage integer DEFAULT 0 NOT NULL,
    current_stage character varying(128),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    execution_duration_seconds double precision,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    error_category character varying(128),
    error_message text,
    result jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ml_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_models (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    dataset_id uuid NOT NULL,
    problem_type character varying(32) NOT NULL,
    algorithm character varying(64) NOT NULL,
    target_column character varying(255) NOT NULL,
    feature_schema jsonb NOT NULL,
    metrics jsonb NOT NULL,
    training_metadata jsonb NOT NULL,
    artifact_filename character varying(255) NOT NULL,
    artifact_sha256 character varying(64) NOT NULL,
    sklearn_version character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


--
-- Name: prediction_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prediction_logs (
    id uuid NOT NULL,
    model_id uuid NOT NULL,
    deployment_id uuid,
    record_count integer DEFAULT 1 NOT NULL,
    duration_ms double precision DEFAULT '0'::double precision NOT NULL,
    status character varying(32) DEFAULT 'success'::character varying NOT NULL,
    problem_type character varying(32) NOT NULL,
    error_category character varying(64),
    error_message text,
    prediction_summary jsonb,
    ground_truth jsonb,
    is_evaluated boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at character varying(64) NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255) DEFAULT ''::character varying NOT NULL,
    role character varying(32) DEFAULT 'viewer'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0007
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasets (id, name, original_filename, stored_filename, file_format, size_bytes, sha256, n_rows, n_columns, columns, created_at, updated_at) FROM stdin;
bf91a9e8-8c00-459a-9412-32b38fcdd6ab	string	sample_students_final.csv	f0efac6fd98b41658a06f8f63c908b81.csv	csv	537	8d2054daea8d14db0391a4424c5881270093ee6c51b230d58c0aedaea429e345	40	5	[{"kind": "numeric", "name": "age", "dtype": "int64"}, {"kind": "numeric", "name": "experience_years", "dtype": "int64"}, {"kind": "numeric", "name": "study_hours", "dtype": "int64"}, {"kind": "numeric", "name": "attendance", "dtype": "int64"}, {"kind": "numeric", "name": "placement", "dtype": "int64"}]	2026-10-30 09:11:11.490087+00	2026-10-30 09:11:11.490087+00
\.


--
-- Data for Name: deployments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deployments (id, model_id, status, version, environment, endpoint_url, configuration, deployed_at, undeployed_at, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drift_alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drift_alerts (id, model_id, drift_report_id, alert_type, severity, feature_name, metric_name, metric_value, threshold, message, resolved, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drift_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drift_reports (id, model_id, report_type, overall_status, results, sample_size, summary, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: experiment_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.experiment_runs (id, experiment_id, run_number, status, best_hyperparameters, validation_metrics, test_metrics, cv_results, registered_model_id, error_message, started_at, completed_at, execution_duration_seconds, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: experiments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.experiments (id, name, description, dataset_id, target_column, problem_type, algorithm, selected_features, hyperparameter_config, search_strategy, cv_folds, scoring_metric, test_size, validation_size, random_state, status, dataset_fingerprint, created_by_id, started_at, completed_at, execution_duration_seconds, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, job_type, status, created_by_id, model_id, experiment_id, input_config, progress_percentage, current_stage, started_at, completed_at, execution_duration_seconds, retry_count, max_retries, error_category, error_message, result, created_at, updated_at) FROM stdin;
6524fe9b-87dd-4964-b696-0583e3be1d71	batch_prediction	failed	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	\N	{"records": [{"age": "invalid", "attendance": 80, "study_hours": 5, "experience_years": 1}]}	50	Execution failed: Prediction input failed validation.	2026-10-30 20:47:42.315325+00	2026-10-30 20:47:42.325212+00	0.0062	0	3	DataValidationError	Prediction input failed validation.	\N	2026-10-30 20:47:40.452036+00	2026-10-30 20:47:42.32332+00
f7293b97-cb29-495a-8510-9ec836475ff2	batch_prediction	completed	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	\N	\N	{"test_run": true, "description": "Docker worker verification"}	100	Task finished successfully	2026-10-30 19:58:59.039792+00	2026-10-30 19:58:59.569575+00	0.5075	0	3	\N	\N	{"status": "success", "processed_at": "2026-10-30T19:58:59.569371+00:00"}	2026-10-30 19:58:58.931797+00	2026-10-30 19:58:59.571792+00
da3c5795-27d1-44ab-bd09-248712076366	batch_prediction	completed	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	\N	{"records": [{"age": 22, "attendance": 92, "study_hours": 8, "experience_years": 1.5}, {"age": 24, "attendance": 78.5, "study_hours": 4.5, "experience_years": 3}], "allow_missing": false}	100	Task finished successfully	2026-10-30 20:23:50.045365+00	2026-10-30 20:23:50.191224+00	0.1385	0	3	\N	\N	{"model_id": "23359afd-b2a4-46c2-afa6-e18d6f77dc9e", "predictions": [1, 1], "problem_type": "classification", "record_count": 2, "probabilities": [{"0": 0.059799, "1": 0.940201}, {"0": 0.416364, "1": 0.583636}]}	2026-10-30 20:23:50.003748+00	2026-10-30 20:23:50.193167+00
be929055-9e99-47ea-8304-cf68b5c566ba	batch_prediction	completed	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	\N	\N	{"concurrent_test": true}	100	Task finished successfully	2026-10-30 20:38:15.625352+00	2026-10-30 20:38:16.143518+00	0.5074	0	3	\N	\N	{"status": "success", "processed_at": "2026-10-30T20:38:16.143332+00:00"}	2026-10-30 20:38:15.036002+00	2026-10-30 20:38:16.147093+00
e04d9212-25ba-47c5-82f9-38b6673df259	batch_prediction	running	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	\N	\N	{"concurrent_test": true}	10	Job claimed by worker	2026-10-30 20:39:56.919152+00	\N	\N	0	3	\N	\N	\N	2026-10-30 20:39:56.885828+00	2026-10-30 20:39:56.910836+00
dacd114c-ff52-48c5-8e12-4ea6d33233a1	batch_prediction	retry_pending	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	\N	{"records": [{"age": 20}]}	50	Failure: Prediction input failed validation.. Scheduled for retry.	2026-10-30 20:42:14.967942+00	2026-10-30 20:42:17.220466+00	2.2442	0	3	DataValidationError	Prediction input failed validation.	\N	2026-10-30 20:42:14.926133+00	2026-10-30 20:42:17.216473+00
200529d6-74f8-4022-82fd-853a6f8e1878	batch_prediction	failed	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	\N	{"records": [{"age": 20}]}	50	Execution failed: Prediction input failed validation.	2026-10-30 20:47:40.474717+00	2026-10-30 20:47:42.297702+00	1.8142	0	3	DataValidationError	Prediction input failed validation.	\N	2026-10-30 20:47:40.427079+00	2026-10-30 20:47:42.293373+00
\.


--
-- Data for Name: ml_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_models (id, name, dataset_id, problem_type, algorithm, target_column, feature_schema, metrics, training_metadata, artifact_filename, artifact_sha256, sklearn_version, created_at, updated_at, version) FROM stdin;
23359afd-b2a4-46c2-afa6-e18d6f77dc9e	Student Placement Classifier	bf91a9e8-8c00-459a-9412-32b38fcdd6ab	classification	linear	placement	[{"kind": "numeric", "name": "age"}, {"kind": "numeric", "name": "experience_years"}, {"kind": "numeric", "name": "study_hours"}, {"kind": "numeric", "name": "attendance"}]	{"test": {"roc_auc": 1.0, "accuracy": 1.0, "f1_macro": 1.0, "log_loss": 0.208071, "n_samples": 8, "recall_macro": 1.0, "precision_macro": 1.0, "confusion_matrix": {"labels": [0, 1], "matrix": [[4, 0], [0, 4]]}, "balanced_accuracy": 1.0}, "train": {"roc_auc": 1.0, "accuracy": 1.0, "f1_macro": 1.0, "log_loss": 0.113015, "n_samples": 24, "recall_macro": 1.0, "precision_macro": 1.0, "confusion_matrix": {"labels": [0, 1], "matrix": [[11, 0], [0, 13]]}, "balanced_accuracy": 1.0}, "validation": {"roc_auc": 1.0, "accuracy": 0.875, "f1_macro": 0.873016, "log_loss": 0.236783, "n_samples": 8, "recall_macro": 0.875, "precision_macro": 0.9, "confusion_matrix": {"labels": [0, 1], "matrix": [[4, 0], [1, 3]]}, "balanced_accuracy": 0.875}, "baseline_test": {"roc_auc": 0.5, "accuracy": 0.5, "f1_macro": 0.333333, "log_loss": 18.021827, "n_samples": 8, "recall_macro": 0.5, "precision_macro": 0.25, "confusion_matrix": {"labels": [0, 1], "matrix": [[0, 4], [0, 4]]}, "balanced_accuracy": 0.5}}	{"rows": {"raw": 40, "test": 8, "used": 40, "train": 24, "validation": 8, "dropped_duplicates": 0, "dropped_missing_target": 0}, "config": {"test_size": 0.2, "random_state": 42, "drop_duplicates": true, "validation_size": 0.2, "problem_type_inferred": false}, "versions": {"numpy": "2.5.4", "pandas": "3.1.0", "scikit-learn": "1.9.1"}, "estimator": "LogisticRegression", "stratified": true, "trained_at": "2026-10-30T09:13:19.544998+00:00", "class_labels": [0, 1], "baseline_model": "DummyClassifier", "dataset_sha256": "8d2054daea8d14db0391a4424c5881270093ee6c51b230d58c0aedaea429e345", "dropped_columns": [], "training_seconds": 0.17, "validation_warnings": []}	2a0b0f6d709749558a4dd98c730871b0.joblib	3d17389cb92f3e3f10b247bbf56177e9145dbf8826b7ea0a0126a62d7b88026e	1.9.1	2026-10-30 09:13:19.361104+00	2026-10-30 09:13:19.361104+00	1
\.


--
-- Data for Name: prediction_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prediction_logs (id, model_id, deployment_id, record_count, duration_ms, status, problem_type, error_category, error_message, prediction_summary, ground_truth, is_evaluated, created_at, updated_at) FROM stdin;
52262b56-0cd4-4057-b3f6-31b5f9b34c4c	23359afd-b2a4-46c2-afa6-e18d6f77dc9e	\N	2	50	success	classification	\N	\N	{"count": 2, "predictions": [1, 1]}	\N	f	2026-10-30 20:23:50.058647+00	2026-10-30 20:23:50.058647+00
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, revoked, created_at, updated_at) FROM stdin;
f424e1a4-364d-4c85-941d-e8a91a29bf45	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	4b061802abb4ae9267690d65d5d1192dce9f68fe360ed080904b7f0124d8065f	2026-11-06T19:54:58.944607+00:00	f	2026-10-30 19:54:58.923321+00	2026-10-30 19:54:58.923321+00
0620377d-5486-43a1-a908-b9573287ff77	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	e9427c74abba5c2d493c882ab33632f94f2651f05e4301fbb1818d7219d779bd	2026-11-06T19:57:36.358915+00:00	f	2026-10-30 19:57:36.299966+00	2026-10-30 19:57:36.299966+00
9f6da7c9-ca66-489e-b9eb-e788c338a129	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	8b9a1d7611f9a09fbc32fc42b8c6a040d185ef3d78cbda64fbf9dcc639fb3fbe	2026-11-06T20:14:08.393378+00:00	f	2026-10-30 20:14:08.379003+00	2026-10-30 20:14:08.379003+00
3dc8a439-5c87-4114-a270-e3b419501234	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	231f672b8af2cb6eea3092d2420142d536700554fe9337327bbd98a6aedcac87	2026-11-06T20:23:49.886257+00:00	f	2026-10-30 20:23:49.874347+00	2026-10-30 20:23:49.874347+00
a50e3ee8-e58f-4e6e-99bd-d2027ab2d7c7	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	2260c5e5c12dbca3eaca4860a8048550bb4ddea6bacd37ff66cfce4835543d8b	2026-11-06T21:02:03.820832+00:00	f	2026-10-30 21:02:03.796259+00	2026-10-30 21:02:03.796259+00
7141e623-1302-4d21-aa38-3e90dde5b7d1	cb83a9e2-4611-4bf8-9f97-f4078712fb2c	4ba629a53fc605d061b95439642b371646c1bb78f1a4301463073bdc126e43d0	2026-11-06T21:07:23.542690+00:00	f	2026-10-30 21:07:23.523892+00	2026-10-30 21:07:23.523892+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, hashed_password, full_name, role, is_active, created_at, updated_at) FROM stdin;
cb83a9e2-4611-4bf8-9f97-f4078712fb2c	missmehak755@gmail.com	$pbkdf2-sha256$29000$ay2FcM75P.d8D.Hcu/f.Hw$hW.wekSM.rLIKTBkcKs.Ko3jawqd6qI4HW0rCWBZ0dY	Mehak	admin	t	2026-10-30 19:54:58.757493+00	2026-10-30 19:54:58.757493+00
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: datasets pk_datasets; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT pk_datasets PRIMARY KEY (id);


--
-- Name: deployments pk_deployments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT pk_deployments PRIMARY KEY (id);


--
-- Name: drift_alerts pk_drift_alerts; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_alerts
    ADD CONSTRAINT pk_drift_alerts PRIMARY KEY (id);


--
-- Name: drift_reports pk_drift_reports; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_reports
    ADD CONSTRAINT pk_drift_reports PRIMARY KEY (id);


--
-- Name: experiment_runs pk_experiment_runs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT pk_experiment_runs PRIMARY KEY (id);


--
-- Name: experiments pk_experiments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT pk_experiments PRIMARY KEY (id);


--
-- Name: jobs pk_jobs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT pk_jobs PRIMARY KEY (id);


--
-- Name: ml_models pk_ml_models; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT pk_ml_models PRIMARY KEY (id);


--
-- Name: prediction_logs pk_prediction_logs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prediction_logs
    ADD CONSTRAINT pk_prediction_logs PRIMARY KEY (id);


--
-- Name: refresh_tokens pk_refresh_tokens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT pk_refresh_tokens PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: datasets uq_datasets_stored_filename; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT uq_datasets_stored_filename UNIQUE (stored_filename);


--
-- Name: ml_models uq_ml_models_artifact_filename; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT uq_ml_models_artifact_filename UNIQUE (artifact_filename);


--
-- Name: ml_models uq_ml_models_name_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT uq_ml_models_name_version UNIQUE (name, version);


--
-- Name: ix_datasets_sha256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_datasets_sha256 ON public.datasets USING btree (sha256);


--
-- Name: ix_deployments_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deployments_model_id ON public.deployments USING btree (model_id);


--
-- Name: ix_deployments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deployments_status ON public.deployments USING btree (status);


--
-- Name: ix_drift_alerts_drift_report_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_alerts_drift_report_id ON public.drift_alerts USING btree (drift_report_id);


--
-- Name: ix_drift_alerts_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_alerts_model_id ON public.drift_alerts USING btree (model_id);


--
-- Name: ix_drift_alerts_resolved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_alerts_resolved ON public.drift_alerts USING btree (resolved);


--
-- Name: ix_drift_alerts_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_alerts_severity ON public.drift_alerts USING btree (severity);


--
-- Name: ix_drift_reports_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_reports_model_id ON public.drift_reports USING btree (model_id);


--
-- Name: ix_drift_reports_overall_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_reports_overall_status ON public.drift_reports USING btree (overall_status);


--
-- Name: ix_drift_reports_report_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drift_reports_report_type ON public.drift_reports USING btree (report_type);


--
-- Name: ix_experiment_runs_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiment_runs_experiment_id ON public.experiment_runs USING btree (experiment_id);


--
-- Name: ix_experiment_runs_registered_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiment_runs_registered_model_id ON public.experiment_runs USING btree (registered_model_id);


--
-- Name: ix_experiment_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiment_runs_status ON public.experiment_runs USING btree (status);


--
-- Name: ix_experiments_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiments_created_by_id ON public.experiments USING btree (created_by_id);


--
-- Name: ix_experiments_dataset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiments_dataset_id ON public.experiments USING btree (dataset_id);


--
-- Name: ix_experiments_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiments_name ON public.experiments USING btree (name);


--
-- Name: ix_experiments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_experiments_status ON public.experiments USING btree (status);


--
-- Name: ix_jobs_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_created_by_id ON public.jobs USING btree (created_by_id);


--
-- Name: ix_jobs_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_experiment_id ON public.jobs USING btree (experiment_id);


--
-- Name: ix_jobs_job_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_job_type ON public.jobs USING btree (job_type);


--
-- Name: ix_jobs_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_model_id ON public.jobs USING btree (model_id);


--
-- Name: ix_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_status ON public.jobs USING btree (status);


--
-- Name: ix_ml_models_dataset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ml_models_dataset_id ON public.ml_models USING btree (dataset_id);


--
-- Name: ix_prediction_logs_deployment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prediction_logs_deployment_id ON public.prediction_logs USING btree (deployment_id);


--
-- Name: ix_prediction_logs_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prediction_logs_model_id ON public.prediction_logs USING btree (model_id);


--
-- Name: ix_prediction_logs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prediction_logs_status ON public.prediction_logs USING btree (status);


--
-- Name: ix_refresh_tokens_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_refresh_tokens_token_hash ON public.refresh_tokens USING btree (token_hash);


--
-- Name: ix_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: deployments fk_deployments_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT fk_deployments_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE CASCADE;


--
-- Name: drift_alerts fk_drift_alerts_drift_report_id_drift_reports; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_alerts
    ADD CONSTRAINT fk_drift_alerts_drift_report_id_drift_reports FOREIGN KEY (drift_report_id) REFERENCES public.drift_reports(id) ON DELETE CASCADE;


--
-- Name: drift_alerts fk_drift_alerts_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_alerts
    ADD CONSTRAINT fk_drift_alerts_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE CASCADE;


--
-- Name: drift_reports fk_drift_reports_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drift_reports
    ADD CONSTRAINT fk_drift_reports_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE CASCADE;


--
-- Name: experiment_runs fk_experiment_runs_experiment_id_experiments; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT fk_experiment_runs_experiment_id_experiments FOREIGN KEY (experiment_id) REFERENCES public.experiments(id) ON DELETE CASCADE;


--
-- Name: experiment_runs fk_experiment_runs_registered_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment_runs
    ADD CONSTRAINT fk_experiment_runs_registered_model_id_ml_models FOREIGN KEY (registered_model_id) REFERENCES public.ml_models(id) ON DELETE SET NULL;


--
-- Name: experiments fk_experiments_created_by_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT fk_experiments_created_by_id_users FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: experiments fk_experiments_dataset_id_datasets; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT fk_experiments_dataset_id_datasets FOREIGN KEY (dataset_id) REFERENCES public.datasets(id) ON DELETE CASCADE;


--
-- Name: jobs fk_jobs_created_by_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_jobs_created_by_id_users FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: jobs fk_jobs_experiment_id_experiments; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_jobs_experiment_id_experiments FOREIGN KEY (experiment_id) REFERENCES public.experiments(id) ON DELETE SET NULL;


--
-- Name: jobs fk_jobs_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT fk_jobs_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE SET NULL;


--
-- Name: ml_models fk_ml_models_dataset_id_datasets; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT fk_ml_models_dataset_id_datasets FOREIGN KEY (dataset_id) REFERENCES public.datasets(id) ON DELETE RESTRICT;


--
-- Name: prediction_logs fk_prediction_logs_deployment_id_deployments; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prediction_logs
    ADD CONSTRAINT fk_prediction_logs_deployment_id_deployments FOREIGN KEY (deployment_id) REFERENCES public.deployments(id) ON DELETE SET NULL;


--
-- Name: prediction_logs fk_prediction_logs_model_id_ml_models; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prediction_logs
    ADD CONSTRAINT fk_prediction_logs_model_id_ml_models FOREIGN KEY (model_id) REFERENCES public.ml_models(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens fk_refresh_tokens_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT fk_refresh_tokens_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict S3L7vPm1957P8hOT2auRxHMiBUc95GhhkPa7bbJ622YhFZLXelmffMWXJ63jr1B

